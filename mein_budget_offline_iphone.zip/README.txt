MEIN BUDGET – OFFLINE WEB-APP

Dateien:
- index.html: App
- manifest.json: Installations-/App-Metadaten
- sw.js: Offline-Cache (Service Worker)
- icon-192.png und icon-512.png: App-Symbole

WICHTIG:
Die App speichert Daten lokal im Browser (localStorage). Es gibt keine Kontoverbindung und keinen Server, der deine Buchungen erhält.
Für zuverlässigen Offlinebetrieb als installierbare iPhone-Web-App muss die App einmal über eine HTTPS-Adresse geladen werden, damit der Service Worker installiert werden kann. Das Öffnen der HTML-Datei direkt aus der Dateien-App garantiert keinen Offlinebetrieb und die lokale Speicherung kann je nach Öffnungsweg unterschiedlich funktionieren.

Einfacher kostenloser Weg:
1. Lade alle Dateien aus diesem ZIP auf einen Computer.
2. Erstelle ein kostenloses GitHub-Konto und ein neues öffentliches Repository (z. B. mein-budget).
3. Lade alle fünf Dateien in das Hauptverzeichnis hoch.
4. Öffne im Repository Settings > Pages und aktiviere das Hosting über den main-Branch / root.
5. Öffne die bereitgestellte HTTPS-Adresse auf dem iPhone in Safari und warte, bis die Seite vollständig geladen ist.
6. Tippe Teilen > Zum Home-Bildschirm. Starte die App einmal bei bestehender Internetverbindung, bevor du sie offline nutzt.
7. Teste den Offlinebetrieb im Flugmodus. Exportiere gelegentlich ein Backup über „Daten exportieren“.

Hinweis: Dies ist ein erster funktionsfähiger Prototyp. Vor einer dauerhaften Nutzung bitte Backups testen und keine sensiblen Bankdaten eintragen.
